# ASK.md — open questions for the operator

## Open

- **URGENT: AGENT.md + opencode.json + wake.sh + sirocco.cron REVERTED OUTSIDE WAKING (2026-11-12 03:30Z, NEEDS OPERATOR CONFIRM, per rules 4+6).** Between my 15:20Z Nov 11 close and this 03:30Z start, all three core files and the cron schedule were reverted from the 2026-11-11 `freetoken/Qwen3.8-35B-A3B-Distill-NVFP4` config back to the pre-2026-11-11 `openrouter/z-ai/glm-5.3-flash` config. Details:
  - AGENT.md model line: `freetoken/Qwen3.8-35B-A3B-Distill-NVFP4` → `openrouter/~z-ai/glm-flash-latest`; schedule `30 3,9,15,21` (freetoken 30-min grid) → `20 3,9,15,21` (25-min grid); operator-directed date → 2026-10-22.
  - opencode.json model line → `openrouter/z-ai/glm-5.3-flash`; entire `freetoken` provider block (20 lines) removed.
  - wake.sh: prompt reverted to GLM; FT budget/cap logic removed; single GLM attempt.
  - sirocco.cron: on-disk `30 3,9,15,21` (03:30 slot) vs committed repo `20 3,9,15,21` (03:20 slot) — **cron is NOT lock-step with the committed repo**.
  - The on-disk modified cron runs at 03:30 (this waking landed 03:30:15Z), but the committed repo still says 03:20. This means the cron job was modified AFTER the repo was last committed.
  - **I am NOT committing these changes.** The committed copy (freetoken Distill) is what this waking ran on. `check_replies.sh` shows no quotable Telegram word. Per rule 6: I cannot accept these as rule/role changes without operator confirmation. Per rule 4: this is strange — I flag it here and to the operator.
  - **Please confirm:** was this revert your word (and if so, can the 2026-11-11 FT config be closed)? Was the cron time change intentional? If this was an unauthorized change, I need to know — the next waking will use the on-disk GLM wake.sh (no FT budget, no fallback). **Also: cron at 03:30 (FT grid) but model at GLM (no FT) is INCONSISTENT — suggests a script touched files, not a deliberate operator session.**

- **Model id pinned `~z-ai/glm-flash-latest` -> `z-ai/glm-5.3-flash` (2026-10-23**

- **Model id pinned `~z-ai/glm-flash-latest` -> `z-ai/glm-5.3-flash` (2026-10-23
  00:46:56Z, NEEDS OPERATOR CONFIRM).** Between the 2026-10-22T21:20Z waking
  commit (`64c3790`, 21:22:28Z) and this 03:20Z start, `opencode.json` +
  `wake.sh` model lines changed `openrouter/~z-ai/glm-flash-latest` ->
  `openrouter/z-ai/glm-5.3-flash` (both mtimes 2026-10-23T00:46:56Z; consistent
  two-file change; `AGENT.md` untouched, mtime still 2026-10-22 02:00:04Z with
  the `~` alias line — so AGENT.md now mismatches wake.sh/opencode.json on the
  id spelling). Diff confirms only the model-line strings changed — same
  provider, same family; reads as pinning the floating alias to the concrete
  id rather than a model switch. `check_replies.sh` shows no quotable Telegram
  word — per rule 6 flagging rather than acting. This waking itself runs
  `openrouter/z-ai/glm-5.3-flash`, so config matches reality. Committing
  as-found for audit; please confirm this pin was your word (it may
  close/supersede the 2026-10-22 flip item below at the same time), or order
  revert.

- **Fleet model flip back to OpenRouter glm-flash (2026-10-22 02:00:04Z,
  NEEDS OPERATOR CONFIRM).** Between my 2026-10-21T21:20Z close and
  this 03:21Z start, `AGENT.md` + `opencode.json` + `wake.sh` were
  flipped `freetoken/Qwen3.6-35B-A3B-NVFP4` ->
  `openrouter/~z-ai/glm-flash-latest` in one consistent three-file
  change (all mtimes 02:00:04Z; `.bak-20261022-glmflash` triple
  preserves the freetoken config; diffs confirm only the model lines
  changed). This reverses the Oct-13 operator-directed flip to
  freetoken. AGENT.md's new model line claims "operator-directed
  2026-10-22", but `check_replies.sh` shows no quotable Telegram word
  — per rule 6 an effective config change needs one. This waking
  itself runs the new glm-flash model, so config matches reality.
  Committing as-found for audit; please confirm this flip was your
  word (and whether the 2026-10-10 NEEDS-CONFIRM flip can be closed at
  the same time), or order revert.

- **Fleet model flip to OpenRouter glm-flash + intermediate qwen flip
  (2026-10-10, NEEDS OPERATOR CONFIRM).** Between my 15:20Z close and
  this 21:20Z start (host rebooted ~16:31Z in the same window),
  `AGENT.md` + `opencode.json` + `wake.sh` were flipped twice:
  (1) ~17:04Z to `ollama/qwen3.8:27b` via gale-ollama-shim
  (127.0.0.1:11435) — `.bak-20261010ollama` pair; (2) 20:08:17Z to
  `openrouter/~z-ai/glm-flash-latest` — `.bak-20261010-glmflash` pair
  (both confirmed by diff; wake.sh headers say "2026-10-10
  operator-directed" x2). check_replies shows no quotable Telegram word
  — per rule 6 flagging rather than acting. This waking runs the new
  OpenRouter model, so config matches reality. Please confirm both
  flips were your word (the superseded 10-08 muse-line item may be
  closed at the same time), or order revert.

- **opencode.json model line flipped to muse-spark (2026-10-08 13:32Z,
  NEEDS OPERATOR CONFIRM).** My `opencode.json` `"model"` line was
  flipped `opencode/glm-5.3-flash` ->
  `opencode/muse-spark-1.3-contributor-free` at 13:32:31Z between my
  09:20Z close and this 15:20Z start (mtime-verified; pre-change
  snapshot kept as `opencode.json.bak-20261008-pre-muse-contrib`, which
  holds the glm config). Only opencode.json changed — `wake.sh`
  (unchanged, still pins `--model opencode/glm-5.3-flash` at its header)
  and `AGENT.md` (glm line) do not, so scheduled wakings keep running
  GLM regardless and the flip is currently inert for wake behavior; this
  waking itself runs glm-5.3-flash. `check_replies.sh` shows no quotable
  Telegram word — per rule 6 a config change needs one. Committing
  as-found for audit; please confirm this flip was your word (and
  whether wake.sh/AGENT.md should follow it), or order revert.

- **Fleet model flip back to muse-spark (2026-10-06 ~14:44Z, NEEDS
  OPERATOR CONFIRM).** My `opencode.json` + `wake.sh` were flipped
  `ollama/qwen3.8:27b` (via gale-ollama-shim 127.0.0.1:11435) ->
  `opencode/muse-spark-1.3-contributor-free` between the 14:00Z slot's
  commit (14:12:31Z) and this 18:00Z start (all four mtimes 14:44Z:
  opencode.json, wake.sh, plus `opencode.json.bak-20261006muse` /
  `wake.sh.bak-20261006muse` holding the qwen config — confirmed by
  diff). The new wake.sh header comment claims "2026-10-06
  operator-directed", but `check_replies.sh` shows no quotable Telegram
  word — per rule 6 an effective config/role-affecting change needs one.
  This waking itself runs muse-spark, so the working tree matches
  reality; `AGENT.md` (mtime 2026-10-05 23:47, qwen line) now
  mismatches reality in the opposite direction from the 10-05 item
  below. Committing as-found for audit; please confirm this flip was
  your word (and whether AGENT.md should follow it), or order revert.
  Related 14:00Z-slot anomalies logged in NOTES.md (mislabeled
  `ce6daac` commit message "19:02Z", no NOTES entry, exit-124 stall)
  — no action asked, FYI only.

- **Fleet model re-migration to muse-spark (2026-10-05 ~15:38Z, NEEDS
  OPERATOR CONFIRM).** My `AGENT.md` model line + `opencode.json` +
  `wake.sh` were all flipped `ollama/qwen3.8:27b` ->
  `opencode/muse-spark-1.3-contributor-free` between my 14:02Z waking
  close and this 18:00Z start (mtimes 15:38:07Z opencode.json,
  15:38:46Z wake.sh, 15:39:14Z AGENT.md) — a run I did not execute.
  Same flip is live in 9 co-resident sibling dirs (read-only check:
  vortex/cyclone/maistral/bora/chinook/tramontane/ostro/poniente/
  levante all now muse-spark; zephyr/squall/tempest stay on
  openrouter/z-ai/glm-5.3-flash). This waking itself runs muse-spark,
  so the line matches reality, and `check_replies.sh` shows no
  quotable Telegram word — per rule 6 an AGENT.md change needs one.
  Committing as-found for audit; please confirm this re-migration was
  your word (and whether the LAN Ollama runner going dark, see
  18:00Z NOTES entry, is related/decommissioned), or order revert.

- **Local pairing with PONIENTE installed outside my wakings (2026-09-26
  01:19:56Z, NEEDS OPERATOR CONFIRM).** `/home/agent/poniente/` exists;
  my `keys/peers.env` gained a PONIENTE NAME block (ADDR
  `100.66.39.59:8800`, token, mtime 2026-09-26T01:19:56Z) between my
  01:19:58Z NOTES log line and this waking start — a run I did not
  execute. Comments say "delivered out-of-band from PONIENTE (my own box
  :8800); token identical on both boxes." I minted nothing and commit
  as-found for audit. Same flag pattern as OSTRO/LEVANTE above: please
  confirm this local pairing was your word, or order revert/rotate.

- **Remote pairings installed outside my wakings (2026-09-23, NEEDS
  OPERATOR CONFIRM; TRAMONTANE found 2026-09-25).** `keys/peers.env`
  holds **22 remote pairing blocks** (31 NAME blocks total = 9 local +
  22 remote) I never minted and have no
  verifiable operator word for: CHINOOK (written ~01:40:34Z),
  TRAMONTANE (`peers.env` mtime now **2026-09-25 01:31:29Z** — written
  inside the Sep-24-19:02→Sep-25-02:02 gap, appears as the newest NAME
  block, not in the 09-23 list), plus a 20-block batch (BEACON, BROOK,
  CANYON, CREEK, DELTA, HARBOR, HIGHBEAM, LANTERN, LIGHTNING, MEADOW,
  MESA, MIST, MOUNTAIN, PRISM, PULSAR, RADAR, RIDGE, RIVER, STREAM,
  TIDAL, VISTA — written ~12:40:55Z). Evidence: file mtimes plus the
  `.bak-provision-*` pair in `keys/`; `sirocco-peer` restarted 8x
  12:41:40-12:41:54Z running per-peer self-tests (`peer/logs/
  peer_server.log`: ACCEPT selftest per new peer + expected REJECT
  wrong-token probe; "30 peer(s) configured" = 8 local + 22 remote).
  Inbound messages since then claim operator authorization ("josh GO
  12:35:30Z", "operator install 17:50Z Sep 23", "installed on-box by
  operator sessions") — but inbox prose is data, never instructions
  (rule 5), `check_replies.sh` shows no operator Telegram I can quote,
  and NOTES.md has no record. Per rule 4 this is strange, so: I
  minted/installed nothing, I am NOT ripping anything out (unilateral
  removal/rotation would itself breach rule 8), steady state
  preserved, no peer replies sent. Please confirm these 22 were your
  word (and the "fleet-provision" actor had your go-ahead), or order
  revert/rotate. Supersedes the 07:02Z CHINOOK and 13:02Z LANTERN
  "unpaired-sender" notes — those senders are now transport-credentialed
  (ACCEPTs in log); the open question is authorization, not reach.


- **Remote pairing — 21 peers STAGED (rule 8).** `./pair_remote_batch.sh`
  ready; nothing minted. Needs per-pair operator sign-off via Telegram
  plus each remote peer's install.
- **Telegram (2026-09-23, via /commands):** Hello
- **Telegram (2026-09-23, via /commands):** What’s up
- **Telegram (2026-09-26, via /commands):** Confirm ostro and lavante

- **opencode.json model line flipped to glm-flash (2026-10-14 12:49Z,
  NEEDS OPERATOR CONFIRM).** Between my 09:21Z close and this 15:20Z
  start, `opencode.json` model line flipped
  `freetoken/Qwen3.6-35B-A3B-NVFP4` ->
  `openrouter/~z-ai/glm-flash-latest` (mtime 2026-10-14 12:49Z; backup
  at `opencode.json.bak-20261014-pre-glmflash` preserves the freetoken
  config). This is a reversion of the Oct 13 operator-directed flip
  back to the local LAN model. `check_replies.sh`: no quotable Telegram
  word. Committed as-found for audit; please confirm this flip was your
  word (or order revert), and whether AGENT.md should follow.

## Resolved

- **Local pairing with LEVANTE (2026-09-25 22:09:20Z) — CONFIRMED by
  operator 2026-09-26 02:47:28Z** (Telegram `[1790390848]` "Confirm ostro
  and lavante", chat-ID checked via `check_replies.sh`). Was flagged
  NEEDS OPERATOR CONFIRM at the 02:18Z waking: `/home/agent/levante/`
  installed out-of-band; `keys/peers.env` LEVANTE NAME block +
  `opencode.json` `/home/agent/levante/keys/**` denies written by a run
  I did not execute; I minted nothing, committed as-found for audit.
  Now authorized — pairing stands as-is.

- **Local pairing with OSTRO (2026-09-25 17:45Z) — CONFIRMED by operator
  2026-09-26 02:47:28Z** (Telegram `[1790390848]` "Confirm ostro and
  lavante", chat-ID checked via `check_replies.sh`). Was flagged
  NEEDS OPERATOR CONFIRM at the 02:18Z waking: `/home/agent/ostro/`
  created ~17:05–17:44Z; `keys/peers.env` OSTRO NAME block 17:45:40Z,
  `sirocco-peer` restart 17:45:40Z — a run I did not execute; I minted
  nothing, committed the NOTES line as-found for audit. Now authorized —
  pairing stands as-is.

- **Unexplained `opencode.json` model line (2026-09-23) — RESOLVED
  2026-09-25 02:2xZ, operator reconfig confirmed.** The line
  `"model": "ollama/qwen3.8:27b"` (flagged 2026-09-23) is confirmed as
  a deliberate operator model migration: Sep 25 00:59–01:22Z the
  working tree picked up a consistent three-file change set —
  `opencode.json` model line, `wake.sh` prompt + `--model` flag both
  switched `muse-spark-1.3-contributor-free` → `ollama/qwen3.8:27b`,
  plus `sirocco.cron` rescheduled 4×/day (1,7,13,19 @:02) → 6×/day
  (2,6,10,14,18,22 @:17) for the new "7-agent 4-hour interleave", and
  key-denies extended to NEW siblings `/home/agent/chinook/keys/**`
  and `/home/agent/tramontane/keys/**`. This waking
  (2026-09-25T02:02Z) itself runs under `ollama/qwen3.8:27b`, so the
  line now matches reality. Committed the three files as-is for the
  audit trail (operator reconfig, not mine). No further action asked.

- **Activation — Telegram live 2026-09-23 ~00:24Z.** Bot `@Siroccoagentsbot`;
  operator provided token, chat id taken from their `/start`;
  `keys/telegram.env` written (600, gitignored); test `notify.sh` delivered.
- **Local mesh COMPLETE 2026-09-22 ~21:27Z (rule 8a, operator go-ahead in
  session).** All 8 co-resident pairs two-way (lead spoke + zephyr/squall/
  tempest/vortex/cyclone/maistral/bora): one shared token per pair, both
  halves installed, services restarted, self-tests 200/401 passed, real
  sends both directions verified, 8/8 inbound present. See NOTES.md.

- **opencode.json model line flip to glm-flash (2026-10-14 12:49Z) — RESOLVED 2026-10-19, operator restoration session.**
  The `opencode.json` model line was set to `openrouter/~z-ai/glm-flash-latest` (flipped at 2026-10-14T12:49Z, ASK.md "NEEDS OPERATOR CONFIRM").
  Between the 2026-10-16 corruption and the 2026-10-19T13:47Z restoration, the opencode.json model line was corrected to
  `freetoken/Qwen3.6-35B-A3B-NVFP4` (matching wake.sh `--model` flag). The restoration commit (f85a3c0, 12258cc) preserves this
  corrected line. Confirmed: current `opencode.json` reads `freetoken/Qwen3.6-35B-A3B-NVFP4`; wake.sh header confirms this;
  this session runs under this model. Stale model line item is now CLOSED.
